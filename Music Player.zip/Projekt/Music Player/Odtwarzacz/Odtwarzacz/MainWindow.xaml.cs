﻿using System;
using System.Windows;
using System.Media;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Media.Imaging;
using System.IO;

namespace Odtwarzacz
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }
        public static string source;    //ścieżka pliku .wav
        String[] file, path;        // tablica nazw i ścieżek plików
        public const string plik1 = "tytuły.txt";     //nazwa pliku do którego zapisuje
        public const string plik2 = "sciezki.txt";
        private void Play_Click(object sender, RoutedEventArgs e)       //funkcja odtwórz
        {
            try
            {
                SoundPlayer muzyka = new SoundPlayer(source);       //klasa SoundPlayer umożliwia odtwarzanie plków wave
                muzyka.Play();
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Wybierz utwór");       // to ci wyskakuje jak dasz play a nie ma wybranego żadnego utworu
            }
        }

        private void Pause_Click(object sender, RoutedEventArgs e)      //funkcja zapauzuj
        {
            try
            {
                SoundPlayer muzyka = new SoundPlayer(source);
                muzyka.Stop();

            }
            catch (ArgumentException)
            {
                MessageBox.Show("Wybierz utwór");
            }
        }

        private void Loop_Click(object sender, RoutedEventArgs e)       //funkcja zapętl
        {
            try
            {
                SoundPlayer muzyka = new SoundPlayer(source);
                muzyka.PlayLooping();
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Wybierz utwór");
            }
        }
        public void LB1_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)        //wybieranie utworów z playlisty
        {
            try
            {
                source = path[LB1.SelectedIndex];       //przeniesienie ścieżki z listy do stringa source
            }
            catch
            {}
        }

        private void Cofnij_Click(object sender, RoutedEventArgs e)     //funkcja cofania utworu o jeden do tyłu
        {
            try
            {
                if (LB1.SelectedIndex > 0)      //nie można cofnąć jeśli utwór jest pierwszy na liście
                {
                    LB1.SelectedIndex -= 1;
                    SoundPlayer muzyka = new SoundPlayer(source);
                    muzyka.Play();
                }
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Wybierz utwór");
            }
        }

        private void Pomin_Click(object sender, RoutedEventArgs e)      //funkcja pomijania utworu
        {
            try
            {
                if (LB1.SelectedIndex == LB1.Items.Count - 1)       //jeśli wybrany jest ostatni utwór to wybiera pierwszy na playliscie
                {
                    LB1.SelectedIndex = 0;
                }
                else
                {
                    LB1.SelectedIndex += 1;
                }
                SoundPlayer muzyka = new SoundPlayer(source);
                muzyka.Play();
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Wybierz utwór");
            }
        }

        private void Zapis_Click(object sender, RoutedEventArgs e)      //zapisywanie tytułów z playlisty do pliku .txt
        {
            StreamWriter SaveFile1 = new StreamWriter(plik1);     //funckja StreamWriter pozwala na zapisanie tekstu do pliku .txt
            foreach (string item in LB1.Items)
            {
                SaveFile1.WriteLine(item);        //zapisywanie kolejnych pozycji z playlisty
                
            }
            SaveFile1.Close();
            MessageBox.Show("Zapisano utwory!");
        }

        private void Losuj_Click(object sender, RoutedEventArgs e)      //funkcja losowego wybrania utworu
        {
            try
            {
                Random rnd = new Random();      //funkcja random do losowania indexu utworu
                {  
                    LB1.SelectedIndex = rnd.Next(LB1.Items.Count);
                }
                SoundPlayer muzyka = new SoundPlayer(source);
                muzyka.Play();
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Dodaj utwory");
            }
        }

        private void Duration_Click(object sender, RoutedEventArgs e)       //funkcja pokazywania czasu trwania utworu
        {
            if(source != null)
            {
                try
                {
                    MessageBox.Show("Czas trwania utworu to " + Time.Czas());       //wyświetlanie czasu trwania utworu
                }
                catch (ArgumentException)
                {
                    MessageBox.Show("Wybierz utwór");
                }
            }
            else
            {
                MessageBox.Show("Wybierz utwór");
            }
        }
        public void Wybieranie_Click(object sender, RoutedEventArgs e)      //dodawanie plików .wav
        {
            OpenFileDialog ofd = new OpenFileDialog();      //funcja OpenFileDialog pozwala na wczytanie pliku z komputera
            ofd.Multiselect = true;
            ofd.DefaultExt = ".wav";        //domyślne rozszerzenie .wav
            bool? result = ofd.ShowDialog();        //otwieranie ofd
            if (result == true)     //sprawdzanie czy jakikolwiek plik został wybrany
            {
                LB1.Items.Clear();
                LB2.Items.Clear();
            }
            file = ofd.SafeFileNames;       //zapisywanie tytułów do tablicy
            path = ofd.FileNames;       //zapisywanie ścieżek do tablicy
            for (int i = 0; i < file.Length; i++)       //pętla dodawania kolejnych pozycji
            {
                LB1.Items.Add(file[i]);   //dodawanie tytułów do listy
                LB2.Items.Clear();
            }
            LB2.Items.Add(LB1.Items.Count);
            LB1.SelectedIndex = 0;
        }
    }
}
