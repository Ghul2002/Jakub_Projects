﻿using System;
using System.IO;

namespace Odtwarzacz
{
    public partial class MainWindow
    {
        public class Time
        {
            static Byte[] Bytes;
            static int byterate;
            public static int duration;
            public static string Czas()
            {
                Bytes = File.ReadAllBytes(source);      //sczytywanie ilości bajtów z pliku
                byterate = BitConverter.ToInt32(new[] { Bytes[28], Bytes[29], Bytes[30], Bytes[31] }, 0);       //sczytywanie ilości bajtów na sekundę z pliku
                duration = (Bytes.Length - 8) / byterate;       //długość trwania pliku
                int minutes = 0;
                string time;
                if (duration > 60)      //zmienianie sekund na minuty i sekundy
                   {
                       minutes = duration / 60;
                       duration = duration - 60 * minutes;
                   }
                if(duration<10)     // dodawanie 0 przed sekudny gdy jest ich mniej niż 10 (żeby było np. 0:04, a nie 0:4)
                {
                    time = Convert.ToString(minutes + ":0" + duration);
                }
                else
                {
                    time = Convert.ToString(minutes + ":" + duration);
                }
                return time;
            }
        }
    }
}
