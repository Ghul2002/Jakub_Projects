﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tic_Tac_Toe
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool player1 = true, player2;
        public string a1, a2, a3, a4, a5, a6, a7, a8, a9;
        public int winner, free_left = 9;
        public MainWindow()
        {
            InitializeComponent();
        }
        public void Winner(ref string b)
        {
            if (b == "X")
            {
                winner = 1;
                TB1.Text = "Player 1";
            }
            else if (b == "O")
            {
                winner = 2;
                TB1.Text = "Player 2";
            }
        }
        public void Choose(ref string a)
        {
            if (player1 == true)
            {
                a = "X";
                player1 = false;
                player2 = true;
                TB1.Text = "Player 2";
            }
            else if (player2 == true)
            {
                a = "O";
                player2 = false;
                player1 = true;
                TB1.Text = "Player 1";
            }
        }
        public void Check()
        {
            if(a1 == a2 && a2 == a3)
            {
                Winner(ref a1);
            }
            else if(a4 == a5 && a5 == a6)
            {
                Winner(ref a4);
            }
            else if (a7 == a8 && a8 == a9)
            {
                Winner(ref a7);
            }
            else if (a1 == a4 && a4 == a7)
            {
                Winner(ref a1);
            }
            else if (a2 == a5 && a5 == a8)
            {
                Winner(ref a2);
            }
            else if (a3 == a6 && a6 == a9)
            {
                Winner(ref a3);
            }
            else if (a1 == a5 && a5 == a9)
            {
                Winner(ref a1);
            }
            else if (a3 == a5 && a5 == a7)
            {
                Winner(ref a3);
            }

            if (winner == 1)
            {

                if (MessageBox.Show("Zwycięża player1!", "Wynik:", MessageBoxButton.OK) == MessageBoxResult.OK)
                {
                    Application.Current.MainWindow.Close();
                }
            }
            else if (winner == 2)
            {
                if (MessageBox.Show("Zwycięża player2!", "Wynik:", MessageBoxButton.OK) == MessageBoxResult.OK)
                {
                    Application.Current.MainWindow.Close();
                }
            }

            TB2.Text = Convert.ToString(free_left);

            if (free_left == 0)
            {
                if (MessageBox.Show("Remis!", "Wynik:", MessageBoxButton.OK) == MessageBoxResult.OK)
                {
                    Application.Current.MainWindow.Close();
                }
            }
        }
        private void Area_1_Click(object sender, RoutedEventArgs e)
        {
            if (a1 == null)
            {
                Choose(ref a1);
                Area_1.Content = a1;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }

        private void Area_2_Click(object sender, RoutedEventArgs e)
        {
            if (a2 == null)
            {
                Choose(ref a2);
                Area_2.Content = a2;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }

        private void Area_3_Click(object sender, RoutedEventArgs e)
        {
            if (a3 == null)
            {
                Choose(ref a3);
                Area_3.Content = a3;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }
        private void Area_4_Click(object sender, RoutedEventArgs e)
        {
            if (a4 == null)
            {
                Choose(ref a4);
                Area_4.Content = a4;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }
        private void Area_5_Click(object sender, RoutedEventArgs e)
        {
            if (a5 == null)
            {
                Choose(ref a5);
                Area_5.Content = a5;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }
        private void Area_6_Click(object sender, RoutedEventArgs e)
        {
            if (a6 == null)
            {
                Choose(ref a6);
                Area_6.Content = a6;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }
        private void Area_7_Click(object sender, RoutedEventArgs e)
        {
            if (a7 == null)
            {
                Choose(ref a7);
                Area_7.Content = a7;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }
        private void Area_8_Click(object sender, RoutedEventArgs e)
        {
            if (a8 == null)
            {
                Choose(ref a8);
                Area_8.Content = a8;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }
        private void Area_9_Click(object sender, RoutedEventArgs e)
        {
            if (a9 == null)
            {
                Choose(ref a9);
                Area_9.Content = a9;
                free_left--;
                Check();
            }
            else
            {
                MessageBox.Show("To pole jest już zajęte");
            }
        }
    }
}
